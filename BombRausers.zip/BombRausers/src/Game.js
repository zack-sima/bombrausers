var highScore = 0;
var StartSceneLayer = cc.Layer.extend({
    ctor : function () {
        this._super();

        this.createStartButton();

        var highScoreLabel = new cc.LabelTTF("Highscore: " + highScore, "Times", 40);
        highScoreLabel.setColor(cc.color(0, 0, 0, 255));
        highScoreLabel.setPosition(cc.winSize.width - 165, cc.winSize.height - 50);
        this.addChild(highScoreLabel, 10);

        var background = new cc.Sprite(res.startBackground_png);
        background.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        this.addChild(background, 1);
        return true;
    },
    createStartButton : function () {
        var startButton = new cc.ControlButton();
        startButton.setZoomOnTouchDown(false);
        startButton.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        startButton.setPreferredSize(cc.size(220, 103));
        startButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.buttonUp_png), cc.CONTROL_STATE_NORMAL);
        startButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.buttonDown_png), cc.CONTROL_STATE_HIGHLIGHTED);
        startButton.addTargetWithActionForControlEvents(this, this.startButtonOnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        this.addChild(startButton, 2);
    },
    startButtonOnClicked : function () {
        cc.director.runScene(new GameScene());
    }
});
var StartScene = cc.Scene.extend({
    onEnter : function () {
        this._super();
        var layer = new StartSceneLayer();
        this.addChild(layer);
    }
});
var GameSceneLayer0 = cc.Layer.extend({
    bulletAmmo : 100,
    bombAmmo : 20,
    healthRegen : 16,
    bulletDisplayArray : null,
    bombDisplayArray : null,
    scoreLabel : null,
    score : 0,
    gameSceneLayer : null,
    redHpBar : null,
    greenHpBar : null,
    onEnter : function () {
        this._super();
        this.addHpBar();
        this.scheduleUpdate();

        this.schedule(this.addBombAmmo, 0.3, cc.REPEAT_FOREVER, 0, "addBombAmmo");
        this.schedule(this.addBulletAmmo, 0.05, cc.REPEAT_FOREVER, 0, "addBulletAmmo");
        this.schedule(function () {
            this.healthRegen = this.healthRegen * 0.975;
        }, 5, cc.REPEAT_FOREVER, 0, "slowHealthRegen");

        this.bulletDisplayArray = [];
        this.bombDisplayArray = [];

        var scoreLabel = new cc.LabelTTF("Score: " + this.score, "Times", 40);
        scoreLabel.setColor(cc.color(0, 0, 0, 255));
        scoreLabel.setPosition(cc.winSize.width - 150, cc.winSize.height - 50);
        this.addChild(scoreLabel, 10);

        this.scoreLabel = scoreLabel;

        for (var i = 1; i <= 100; i++) {
            var bullet = new cc.Sprite(res.bulletDisplay_png);
            bullet.setPosition(cc.winSize.width / 2 - 102 + i * 2, cc.winSize.height - 50);
            this.addChild(bullet);
            this.bulletDisplayArray.push(bullet);
        }
        for (var i = 1; i <= 20; i++) {
            var bomb = new cc.Sprite(res.bombDisplay_png);
            bomb.setPosition(cc.winSize.width / 2 - 102 + i * 4, cc.winSize.height - 70);
            this.addChild(bomb);
            this.bombDisplayArray.push(bomb);
        }
    },
    addBulletAmmo : function () {
        if (this.bulletAmmo < 100 && this.gameSceneLayer.fireBullet == false) {
            this.bulletAmmo++;
            this.updateAmmoBars();
        }
    },
    addBombAmmo : function () {
        if (this.bombAmmo < 20 && this.gameSceneLayer.fireBomb == false) {
            this.bombAmmo++;
            this.updateAmmoBars();
        }
    },
    updateAmmoBars : function () {
        for (var i in this.bulletDisplayArray) {
            if (i >= this.bulletAmmo) {
                this.bulletDisplayArray[i].setOpacity(30);
            } else {
                this.bulletDisplayArray[i].setOpacity(255);
            }
        }
        for (var a = 0; a <= 19; a++) {
            if (a >= this.bombAmmo) {
                this.bombDisplayArray[a].setOpacity(30);
            } else {
                this.bombDisplayArray[a].setOpacity(255);
            }
        }
    },
    updateHpBar : function () {
        var k = this.gameSceneLayer.player.hp / this.gameSceneLayer.player.maxHp;
        var newLength = k * 200;
        this.greenHpBar.setPreferredSize(cc.size(newLength, 16))
    },
    addHpBar : function () {
        var redHpBar = new cc.Scale9Sprite(res.redHpBar_png, cc.rect(0, 0, 100, 8), cc.rect(0, 0, 100, 8));
        redHpBar.setPreferredSize(cc.size(200, 16));
        redHpBar.setAnchorPoint(0, 0.5);
        redHpBar.setPosition(50, cc.winSize.height - 50);
        this.addChild(redHpBar, 10);
        this.redHpBar = redHpBar;

        var greenHpBar = new cc.Scale9Sprite(res.greenHpBar_png, cc.rect(0, 0, 100, 8), cc.rect(0, 0, 100, 8));
        greenHpBar.setPreferredSize(cc.size(200, 16));
        greenHpBar.setAnchorPoint(0, 0.5);
        greenHpBar.setPosition(50, cc.winSize.height - 50);
        this.addChild(greenHpBar, 10);
        this.greenHpBar = greenHpBar;
    },
    update : function (dt) {
        this.scoreLabel.setString("Score: " + this.score);
        if (this.score > highScore) {
            highScore = this.score;
        }
        if (this.gameSceneLayer.player.hp <= 0) {
            this.gameSceneLayer.player.hp = 0;
            this.updateHpBar();

            var grayShade = new cc.Sprite(res.grayShade_png);
            grayShade.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
            this.addChild(grayShade, 20);

            cc.director.pause();

            var gameOverText = new cc.Sprite(res.gameOverText_png);
            gameOverText.setPosition(cc.winSize.width / 2, cc.winSize.height / 2 + 100);
            this.addChild(gameOverText, 21);

            var menuButton = new cc.ControlButton();
            menuButton.setZoomOnTouchDown(false);
            menuButton.setPosition(cc.winSize.width / 2, cc.winSize.height / 2 - 100);
            menuButton.setPreferredSize(cc.size(220, 103));
            menuButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.menuButton_png), cc.CONTROL_STATE_NORMAL);
            menuButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.menuButtonPressed_png), cc.CONTROL_STATE_HIGHLIGHTED);
            menuButton.addTargetWithActionForControlEvents(this, function () {
                cc.director.runScene(new StartScene());
            }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            this.addChild(menuButton, 21);
        }
        if (this.gameSceneLayer.player.hp < this.gameSceneLayer.player.maxHp && this.gameSceneLayer.fireBullet == false && this.gameSceneLayer.fireBomb == false) {
            this.gameSceneLayer.player.hp += this.healthRegen * dt;
            this.updateHpBar();
        }
    }
});
var GameSceneLayer1 = cc.Layer.extend({
    boatDelay : 10,
    cargoBoatDelay : 25,
    carrierBoatDelay : 60,
    backgroundLayer : null,
    boundaryLeft : 0,
    boundaryRight : 1024,
    boatArray : null,
    forwardForce : 0,
    maxForwardForce : 10,
    gravity : 0.11,
    maxGravity : 8,
    downForce : 0,
    player : null,
    water : null,
    background : null,
    moveForward : false,
    rotateLeft : false,
    rotateRight : false,
    fireBullet : false,
    fireBomb : false,
    fireBombInProgress : false,
    leftButton : null,
    rightButton : null,
    upButton : null,
    fireBulletButton : null,
    fireBombButton : null,
    pauseButton : null,
    paused : false,
    resumeButton : null,
    grayShade : null,
    ctor : function () {
        this._super();

        this.boatArray = [];

        for (var i = 1; i <= 9; i++) {
            this.addCloud(this.getRandomInRange(0, cc.winSize.width / 3), this.getRandomInRange(cc.winSize.height * i, cc.winSize.height * (i + 1)));
            this.addCloud(this.getRandomInRange(cc.winSize.width / 3, cc.winSize.width / 3 * 2), this.getRandomInRange(cc.winSize.height * i, cc.winSize.height * (i + 1)));
            this.addCloud(this.getRandomInRange(cc.winSize.width / 3 * 2, cc.winSize.width / 3 * 3), this.getRandomInRange(cc.winSize.height * i, cc.winSize.height * (i + 1)));
        }

        this.addTouch();
        this.addBackground();
        this.addPlayer();
        this.addWater();
        this.addSand(cc.winSize.width / 2);
        this.addKeyboard();
        this.schedule(this.detectMotion, 0.01, cc.REPEAT_FOREVER, 0, "motionSchedule");
        this.addBoat1();
        this.schedule(this.spawnBullet, 0.022, cc.REPEAT_FOREVER, 0, "playerBulletSchedule");
        this.schedule(this.updateBoatSpawnTime, 7.5, cc.REPEAT_FOREVER, 0, " updateBoatSpawnSchedule");
        this.scheduleUpdate();

        var delay = new cc.DelayTime(this.cargoBoatDelay);
        var spawnBoat = new cc.CallFunc(this.addBoat2, this);
        var seq = new cc.Sequence([delay, spawnBoat]);
        this.runAction(seq);

        var delay1 = new cc.DelayTime(this.carrierBoatDelay);
        var spawnBoat1 = new cc.CallFunc(this.addBoat3, this);
        var seq1 = new cc.Sequence([delay1, spawnBoat1]);
        this.runAction(seq1);

        var delay2 = new cc.DelayTime(0.1);
        var addKeyboardButtons = new cc.CallFunc(this.addKeyboardButtons, this);
        var seq2 = new cc.Sequence([delay2, addKeyboardButtons]);
        this.runAction(seq2);

        var delay3 = new cc.DelayTime(0.1);
        var addPause = new cc.CallFunc(function () {
            var pauseButton = new cc.Sprite(res.pause_png);
            pauseButton.setPosition(cc.winSize.width - 25, cc.winSize.height - 25);
            this.backgroundLayer.addChild(pauseButton, 3);
            this.pauseButton = pauseButton;
        }, this);
        var seq3 = new cc.Sequence([delay3, addPause]);
        this.runAction(seq3);

        return true;
    },
    addPlayer : function () {
        var player = new Player(res.bomber_png);
        player.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        this.addChild(player, 4);
        this.player = player;
        var follow = new cc.Follow(this.player);
        this.runAction(follow);
    },
    getRandomInRange : function (min, max) {
        return Math.random() * (max - min) + min;
    },
    updateBoatSpawnTime : function () {
        this.boatDelay = this.boatDelay * 0.95;
        this.cargoBoatDelay = this.cargoBoatDelay * 0.95;
        this.carrierBoatDelay = this.carrierBoatDelay * 0.96;
    },
    addBoat1 : function () {
        var boat = new Boat(res.sailBoat_png);
        boat.setPosition(this.player.x + cc.winSize.width / 1.5, 76 + 150);
        boat.gameSceneLayer = this;
        this.addChild(boat, 3);
        this.boatArray.push(boat);
        var boat1 = new Boat(res.sailBoat_png);
        boat1.setPosition(this.player.x - cc.winSize.width / 1.5, 76 + 150);
        boat1.gameSceneLayer = this;
        this.addChild(boat1, 3);
        this.boatArray.push(boat1);

        var delay = new cc.DelayTime(this.boatDelay);
        var func = new cc.CallFunc(this.addBoat1, this);
        var seq = new cc.Sequence([delay, func]);
        this.runAction(seq);
    },
    addBoat2 : function () {
        var boat = new CargoBoat(res.cargoBoat_png);
        boat.setPosition(this.player.x + cc.winSize.width * 1.5, 60 + 150);
        boat.gameSceneLayer = this;
        this.addChild(boat, 3);
        this.boatArray.push(boat);
        var boat1 = new CargoBoat(res.cargoBoat_png);
        boat1.setPosition(this.player.x - cc.winSize.width * 1.5, 60 + 150);
        boat1.gameSceneLayer = this;
        this.addChild(boat1, 3);
        this.boatArray.push(boat1);

        var delay = new cc.DelayTime(this.cargoBoatDelay);
        var func = new cc.CallFunc(this.addBoat2, this);
        var seq = new cc.Sequence([delay, func]);
        this.runAction(seq);
    },
    addBoat3 : function () {
        var boat = new AircraftCarrier(res.carrier_png);
        boat.setPosition(this.player.x + cc.winSize.width * 1.5, 60 + 150);
        boat.gameSceneLayer = this;
        this.addChild(boat, 3);
        this.boatArray.push(boat);

        var boat1 = new AircraftCarrier(res.carrier_png);
        boat1.setPosition(this.player.x - cc.winSize.width * 1.5, 60 + 150);
        boat1.gameSceneLayer = this;
        this.addChild(boat1, 3);
        this.boatArray.push(boat1);

        var delay = new cc.DelayTime(this.carrierBoatDelay);
        var func = new cc.CallFunc(this.addBoat3, this);
        var seq = new cc.Sequence([delay, func]);
        this.runAction(seq);
    },
    update : function (dt) {
        if (this.player.getRotation() > 360) {
            this.player.setRotation(this.player.getRotation() - 360);
        }
        if (this.player.getRotation() < 0) {
            this.player.setRotation(this.player.getRotation() + 360);
        }
        if (this.player.getPosition().y > cc.winSize.height * 5) {
            this.player.hp -= dt * ((this.player.getPosition().y - cc.winSize.height * 5) / 75);
            this.backgroundLayer.updateHpBar();
        }
    },
    addWater : function () {
        var water = new cc.Sprite(res.water_png);
        water.setPosition(cc.winSize.width / 2, -600);
        water.setOpacity(150);
        this.addChild(water, 5);
        this.water = water;
    },
    addSand : function (x) {
        var sand = new cc.Sprite(res.sand_png);
        sand.setPosition(x, -1600);
        this.addChild(sand, 5);
    },
    addBackground : function () {
        var background = new cc.Sprite(res.background_png);
        background.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        this.addChild(background, 1);
        this.background = background;
    },
    addCloud : function (x, y) {
        var cloud = new Cloud(res.cloud_png);
        cloud.setPosition(x, y);
        cloud.gameSceneLayer = this;
        cloud.setOpacity(180);
        this.addChild(cloud, 4);
    },
    spawnBullet : function () {
        if (this.fireBullet == true && this.backgroundLayer.bulletAmmo > 0) {
            this.backgroundLayer.bulletAmmo --;
            this.backgroundLayer.updateAmmoBars();
            var bullet = new PlayerBullet(res.bullet_png);
            bullet.setPosition(cc.pAdd(cc.pRotateByAngle(cc.p(this.player.getContentSize().width / 2, -7), cc.p(0, 0), -(this.player.getRotation() / 360 * Math.PI * 2)), cc.p(this.player.x, this.player.y)));
            bullet.setRotation(this.player.getRotation() + this.getRandomInRange(-3, 3));
            bullet.gameSceneLayer = this;
            this.addChild(bullet, 2);
        }
    },
    spawnBomb : function () {
        if (this.fireBomb == true && this.fireBombInProgress == false && this.backgroundLayer.bombAmmo > 0) {
            this.backgroundLayer.bombAmmo --;
            this.backgroundLayer.updateAmmoBars();
            var bullet = new PlayerBomb(res.bomb_png);
            bullet.setPosition(this.player.x, this.player.y);
            bullet.setRotation(0);
            bullet.gameSceneLayer = this;
            this.addChild(bullet, 2);
            var delay = new cc.DelayTime(0.1);
            var change = new cc.CallFunc(function () {
                this.fireBombInProgress = true;
            }, this);
            var changeBack = new cc.CallFunc(function () {
                this.fireBombInProgress = false;
            }, this);
            var seq = new cc.Sequence([change, delay, changeBack]);
            this.runAction(seq);
        }
    },
    detectMotion : function () {
        this.spawnBomb();
        if (this.player.x < this.boundaryLeft + cc.winSize.width) {
            this.boundaryLeft -= cc.winSize.width;
            this.addSand(this.boundaryLeft + cc.winSize.width / 2);
            for (var a = 1; a <= 9; a++) {
                for (var i = 1; i <= 3; i++) {
                    this.addCloud(this.getRandomInRange(this.boundaryLeft + cc.winSize.width / 3 * (i - 1), this.boundaryLeft + cc.winSize.width / 3 * i), this.getRandomInRange(cc.winSize.height * a, cc.winSize.height * (a + 1)));
                }
            }
        }
        if (this.player.x > this.boundaryRight - cc.winSize.width) {
            this.boundaryRight += cc.winSize.width;
            this.addSand(this.boundaryRight - cc.winSize.width / 2);
            for (var a = 1; a <= 9; a++) {
                for (var i = 1; i <= 3; i++) {
                    this.addCloud(this.getRandomInRange(this.boundaryRight + cc.winSize.width / 3 * (i - 1), this.boundaryRight + cc.winSize.width / 3 * i), this.getRandomInRange(cc.winSize.height * a, cc.winSize.height * (a + 1)));
                }
            }
        }
        if (this.moveForward == false) {
            if (this.downForce < this.maxGravity) {
                this.downForce = this.downForce + this.gravity;
            }
        } else {
            if (this.downForce > 0) {
                this.downForce -= 0.25;
            }
        }
        this.player.setPosition(this.player.getPosition().x, this.player.getPosition().y - this.downForce);
        if (this.moveForward == true) {
            if (this.forwardForce < this.maxForwardForce) {
                this.forwardForce += 0.2;
            }
        } else if (this.forwardForce > 0) {
            this.forwardForce -= 0.10;
        }
        this.player.setPosition(cc.pAdd(this.player.getPosition(), cc.pRotateByAngle(cc.p(this.forwardForce, 0), cc.p(0, 0), -(this.player.getRotation() / 360 * Math.PI * 2))));
        if (this.rotateLeft == true) {
            this.player.setRotation(this.player.getRotation() - 2.8);
        }
        if (this.rotateRight == true) {
            this.player.setRotation(this.player.getRotation() + 2.8);
        }
        if (this.player.y < -1200) {
            this.player.hp = 0;
        }
        this.background.setPosition(this.player.getPosition());
        this.water.setPosition(this.player.getPosition().x, this.water.getPosition().y);
    },
    addKeyboardButtons : function () {
        var upButton = new cc.ControlButton();
        upButton.setPosition(cc.winSize.width - 160, 160);
        upButton.setPreferredSize(cc.size(80, 80));
        upButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.upButton_png), cc.CONTROL_STATE_NORMAL);
        upButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.upButton_png), cc.CONTROL_STATE_HIGHLIGHTED);
        upButton.addTargetWithActionForControlEvents(this, function () {
            this.moveForward = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        upButton.addTargetWithActionForControlEvents(this, function () {
            this.moveForward = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
        upButton.addTargetWithActionForControlEvents(this, function () {
            this.moveForward = true;
        }, cc.CONTROL_EVENT_TOUCH_DOWN);
        this.backgroundLayer.addChild(upButton, 3);

        var rightButton = new cc.ControlButton();
        rightButton.setPosition(cc.winSize.width - 80, 80);
        rightButton.setPreferredSize(cc.size(80, 80));
        rightButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.rightButton_png), cc.CONTROL_STATE_NORMAL);
        rightButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.rightButton_png), cc.CONTROL_STATE_HIGHLIGHTED);
        rightButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateRight = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        rightButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateRight = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
        rightButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateRight = true;
        }, cc.CONTROL_EVENT_TOUCH_DOWN);
        this.backgroundLayer.addChild(rightButton, 3);

        var leftButton = new cc.ControlButton();
        leftButton.setPosition(cc.winSize.width - 240, 80);
        leftButton.setPreferredSize(cc.size(80, 80));
        leftButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.leftButton_png), cc.CONTROL_STATE_NORMAL);
        leftButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.leftButton_png), cc.CONTROL_STATE_HIGHLIGHTED);
        leftButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateLeft = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        leftButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateLeft = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
        leftButton.addTargetWithActionForControlEvents(this, function () {
            this.rotateLeft = true;
        }, cc.CONTROL_EVENT_TOUCH_DOWN);
        this.backgroundLayer.addChild(leftButton, 3);

        var fireBulletButton = new cc.ControlButton();
        fireBulletButton.setPosition(80, 80);
        fireBulletButton.setPreferredSize(cc.size(80, 80));
        fireBulletButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.bulletButton_png), cc.CONTROL_STATE_NORMAL);
        fireBulletButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.bulletButton_png), cc.CONTROL_STATE_HIGHLIGHTED);
        fireBulletButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBullet = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        fireBulletButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBullet = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
        fireBulletButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBullet = true;
        }, cc.CONTROL_EVENT_TOUCH_DOWN);
        this.backgroundLayer.addChild(fireBulletButton, 3);

        var fireBombButton = new cc.ControlButton();
        fireBombButton.setPosition(240, 80);
        fireBombButton.setPreferredSize(cc.size(80, 80));
        fireBombButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.bombButton_png), cc.CONTROL_STATE_NORMAL);
        fireBombButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.bombButton_png), cc.CONTROL_STATE_HIGHLIGHTED);
        fireBombButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBomb = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        fireBombButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBomb = false;
        }, cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
        fireBombButton.addTargetWithActionForControlEvents(this, function () {
            this.fireBomb = true;
        }, cc.CONTROL_EVENT_TOUCH_DOWN);
        this.backgroundLayer.addChild(fireBombButton, 3);
    },
    addKeyboard : function () {
        var self = this;
        var l = cc.EventListener.create({
            event : cc.EventListener.KEYBOARD,
            onKeyPressed : function (keyCode, event) {
                if (keyCode == cc.KEY.up) {
                    self.moveForward = true;
                }
                if (keyCode == cc.KEY.left) {
                    self.rotateLeft = true;
                }
                if (keyCode == cc.KEY.right) {
                    self.rotateRight = true;
                }
                if (keyCode == cc.KEY.f) {
                    self.fireBullet = true;
                }
                if (keyCode == cc.KEY.space) {
                    self.fireBomb = true;
                }
                if (keyCode == cc.KEY.escape) {
                    if (self.paused == false) {
                        self.pauseGame();
                    } else {
                        cc.director.resume();
                        self.paused = false;
                        self.resumeButton.removeFromParent();
                        self.grayShade.removeFromParent();
                    }
                }
            },
            onKeyReleased : function (keyCode, event) {
                if (keyCode == cc.KEY.up) {
                    self.moveForward = false;
                }
                if (keyCode == cc.KEY.left) {
                    self.rotateLeft = false;
                }
                if (keyCode == cc.KEY.right) {
                    self.rotateRight = false;
                }
                if (keyCode == cc.KEY.f) {
                    self.fireBullet = false;
                }
                if (keyCode == cc.KEY.space) {
                    self.fireBomb = false;
                }
            }
        });
        cc.eventManager.addListener(l, this);
    },
    addTouch : function () {
        var self = this;
        var listener = cc.EventListener.create({
            event : cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches : true,
            onTouchBegan : function (touch, event) {
                var rectTarget = self.pauseButton;
                if (cc.rectContainsPoint(cc.rect(rectTarget.x - rectTarget.getContentSize().width / 2, rectTarget.y - rectTarget.getContentSize().height / 2, rectTarget.getContentSize().width, rectTarget.getContentSize().height), touch.getLocation())) {
                    self.pauseGame();
                }
                return true;
            },
            onTouchMoved : function (touch, event) {
            },
            onTouchEnded : function (touch, event) {
            }
        });
        cc.eventManager.addListener(listener, this);
    },
    pauseGame : function () {
        this.paused = true;
        var grayShade = new cc.Sprite(res.grayShade_png);
        grayShade.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        this.backgroundLayer.addChild(grayShade, 20);
        cc.director.pause();
        var resumeButton = new cc.ControlButton();
        resumeButton.setZoomOnTouchDown(false);
        resumeButton.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        resumeButton.setPreferredSize(cc.size(220, 103));
        resumeButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.resumeButton_png), cc.CONTROL_STATE_NORMAL);
        resumeButton.setBackgroundSpriteForState(new cc.Scale9Sprite(res.resumeButtonPressed_png), cc.CONTROL_STATE_HIGHLIGHTED);
        resumeButton.addTargetWithActionForControlEvents(this, function () {
            cc.director.resume();
            this.paused = false;
            resumeButton.removeFromParent();
            grayShade.removeFromParent();
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        this.backgroundLayer.addChild(resumeButton, 21);
        this.resumeButton = resumeButton;
        this.grayShade = grayShade;
    }
});
var GameScene = cc.Scene.extend({
    ctor : function () {
        this._super();
        cc.director.resume();
        return true;
    },
    onEnter : function () {
        this._super();
        var layer = new GameSceneLayer1();
        this.addChild(layer, 1);
        var background = new GameSceneLayer0();
        background.gameSceneLayer = layer;
        this.addChild(background, 2);
        layer.backgroundLayer = background;
    }
});
var Player = cc.Sprite.extend({
    maxHp : 100,
    hp : 100,
    ctor : function (a) {
        this._super(a);

        return true;
    }
});
var Cloud = cc.Sprite.extend({
    randomMove : 0,
    gameSceneLayer : null,
    onEnter : function () {
        this._super();
        this.randomMove = this.gameSceneLayer.getRandomInRange(-20, 20);
        this.scheduleUpdate();
    },
    update : function (dt) {
        this.setPosition(this.x + this.randomMove * dt, this.y);
    }
});
var Boat = cc.Sprite.extend({
    health : 25,
    gameSceneLayer : null,
    cannon : null,
    randomMove : 0,
    onEnter : function () {
        this._super();

        var boatCannon = new cc.Sprite(res.boatCannon_png);
        boatCannon.setPosition(this.getContentSize().width / 2, 10);

        this.gameSceneLayer.addChild(boatCannon, 3);

        this.cannon = boatCannon;

        this.randomMove = this.gameSceneLayer.getRandomInRange(-100, 100);

        this.schedule(this.spawnBullet, 1, cc.REPEAT_FOREVER, 0, "bulletSchedule");

        this.scheduleUpdate();
    },
    loseHealth : function (damage) {
        this.health -= damage;
        if (this.health <= 0) {
            this.destroySelf();
        } else {
            var tint = new cc.TintTo(0.08, 0, 0, 0);
            var tintBack = new cc.TintTo(0.08, 255, 255, 255);
            var seq = new cc.Sequence([tint, tintBack]);
            this.runAction(seq);
        }
    },
    destroySelf : function () {
        for (var i in this.gameSceneLayer.boatArray) {
            if (this.gameSceneLayer.boatArray[i] == this) {
                this.gameSceneLayer.boatArray.splice(i, 1);
                break;
            }
        }
        this.gameSceneLayer.backgroundLayer.score += 10;
        var tint = new cc.TintTo(0.12, 0, 0, 0);
        var destroy = new cc.CallFunc(this.removeFromParent, this);
        var destroyChildren = new cc.CallFunc(this.cannon.removeFromParent, this.cannon);
        var seq = new cc.Sequence([tint, destroyChildren, destroy]);
        this.runAction(seq);
    },
    spawnBullet : function () {
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.cannon.getPosition()) <= cc.winSize.width * 4) {
            var bullet = new CannonBullet(res.cannonBall_png);
            bullet.setPosition(this.cannon.x, this.cannon.y);
            bullet.setRotation(this.cannon.getRotation() - 90);
            bullet.gameSceneLayer = this.gameSceneLayer;
            this.gameSceneLayer.addChild(bullet, 2);
        }
    },
    update : function (dt) {
        this.setPosition(this.x + this.randomMove * dt, this.y);

        var vector = cc.pSub(this.cannon.getPosition(), this.gameSceneLayer.player.getPosition());
        var vn = cc.pNormalize(vector);

        var radian = cc.pToAngle(vn);
        var angle = radian * 180 / Math.PI;

        this.cannon.setRotation(270 - angle);
        this.cannon.setPosition(this.x, this.y - 60);
    }
});
var CargoBoat = cc.Sprite.extend({
    health : 48,
    gameSceneLayer : null,
    cannon : null,
    cannon1 : null,
    randomMove : 0,
    onEnter : function () {
        this._super();

        var boatCannon = new cc.Sprite(res.boatCannon_png);
        boatCannon.setPosition(this.getContentSize().width / 2 - 150, 10);
        this.gameSceneLayer.addChild(boatCannon, 3);
        this.cannon = boatCannon;

        var boatCannon1 = new cc.Sprite(res.boatCannon_png);
        boatCannon1.setPosition(this.getContentSize().width / 2 + 150, 10);
        this.gameSceneLayer.addChild(boatCannon1, 3);
        this.cannon1 = boatCannon1;

        this.randomMove = this.gameSceneLayer.getRandomInRange(-100, 100);

        this.schedule(this.spawnBullet, 1, cc.REPEAT_FOREVER, 0, "bulletSchedule");

        this.scheduleUpdate();
    },
    loseHealth : function (damage) {
        this.health -= damage;
        if (this.health <= 0) {
            this.destroySelf();
        } else {
            var tint = new cc.TintTo(0.08, 0, 0, 0);
            var tintBack = new cc.TintTo(0.08, 255, 255, 255);
            var seq = new cc.Sequence([tint, tintBack]);
            this.runAction(seq);
        }
    },
    destroySelf : function () {
        for (var i in this.gameSceneLayer.boatArray) {
            if (this.gameSceneLayer.boatArray[i] == this) {
                this.gameSceneLayer.boatArray.splice(i, 1);
                break;
            }
        }
        this.gameSceneLayer.backgroundLayer.score += 25;
        var tint = new cc.TintTo(0.12, 0, 0, 0);
        var destroy = new cc.CallFunc(this.removeFromParent, this);
        var destroyChildren = new cc.CallFunc(this.cannon.removeFromParent, this.cannon);
        var destroyChildren1 = new cc.CallFunc(this.cannon1.removeFromParent, this.cannon1);
        var seq = new cc.Sequence([tint, destroyChildren, destroyChildren1, destroy]);
        this.runAction(seq);
    },
    spawnBullet : function () {
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.cannon.getPosition()) <= cc.winSize.width * 4) {
            var bullet = new CannonBullet(res.cannonBall_png);
            bullet.setPosition(this.cannon.x, this.cannon.y);
            bullet.setRotation(this.cannon.getRotation() - 90);
            bullet.gameSceneLayer = this.gameSceneLayer;
            this.gameSceneLayer.addChild(bullet, 2);
        }
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.cannon1.getPosition()) <= cc.winSize.width * 4) {
            var bullet = new CannonBullet(res.cannonBall_png);
            bullet.setPosition(this.cannon1.x, this.cannon1.y);
            bullet.setRotation(this.cannon1.getRotation() - 90);
            bullet.gameSceneLayer = this.gameSceneLayer;
            this.gameSceneLayer.addChild(bullet, 2);
        }
    },
    update : function (dt) {
        this.setPosition(this.x + this.randomMove * dt, this.y);

        var vector = cc.pSub(this.cannon.getPosition(), this.gameSceneLayer.player.getPosition());
        var vn = cc.pNormalize(vector);

        var radian = cc.pToAngle(vn);
        var angle = radian * 180 / Math.PI;

        var vector1 = cc.pSub(this.cannon1.getPosition(), this.gameSceneLayer.player.getPosition());
        var vn1 = cc.pNormalize(vector1);

        var radian1 = cc.pToAngle(vn1);
        var angle1 = radian1 * 180 / Math.PI;

        this.cannon.setRotation(270 - angle);
        this.cannon.setPosition(this.x - 120, this.y - 30);

        this.cannon1.setRotation(270 - angle1);
        this.cannon1.setPosition(this.x + 120, this.y - 30);
    }
});
var AircraftCarrier = cc.Sprite.extend({
    health : 90,
    gameSceneLayer : null,
    cannon : null,
    cannon1 : null,
    randomMove : 0,
    onEnter : function () {
        this._super();

        var boatCannon = new cc.Sprite(res.boatCannon_png);
        boatCannon.setPosition(this.getContentSize().width / 2 - 150, 10);
        this.gameSceneLayer.addChild(boatCannon, 3);
        this.cannon = boatCannon;

        var boatCannon1 = new cc.Sprite(res.boatCannon_png);
        boatCannon1.setPosition(this.getContentSize().width / 2 + 150, 10);
        this.gameSceneLayer.addChild(boatCannon1, 3);
        this.cannon1 = boatCannon1;

        this.randomMove = this.gameSceneLayer.getRandomInRange(-100, 100);

        this.schedule(this.spawnBullet, 1, cc.REPEAT_FOREVER, 0, "bulletSchedule");
        this.scheduleOnce(this.spawnMissile, 5, "firstMissileSchedule");
        this.schedule(this.spawnMissile, 25, cc.REPEAT_FOREVER, 0, "missileSchedule");

        this.scheduleUpdate();
    },
    spawnMissile : function () {
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.getPosition()) <= cc.winSize.width * 8) {
            var missile = new Missile(res.missile_png);
            missile.gameSceneLayer = this.gameSceneLayer;
            missile.setRotation(0);
            missile.setPosition(this.getPosition().x, this.getPosition().y + 10);
            this.gameSceneLayer.addChild(missile, 2);
        }
    },
    loseHealth : function (damage) {
        this.health -= damage;
        if (this.health <= 0) {
            this.destroySelf();
        } else {
            var tint = new cc.TintTo(0.08, 0, 0, 0);
            var tintBack = new cc.TintTo(0.08, 255, 255, 255);
            var seq = new cc.Sequence([tint, tintBack]);
            this.runAction(seq);
        }
    },
    destroySelf : function () {
        for (var i in this.gameSceneLayer.boatArray) {
            if (this.gameSceneLayer.boatArray[i] == this) {
                this.gameSceneLayer.boatArray.splice(i, 1);
                break;
            }
        }
        this.gameSceneLayer.backgroundLayer.score += 75;
        var tint = new cc.TintTo(0.12, 0, 0, 0);
        var destroy = new cc.CallFunc(this.removeFromParent, this);
        var destroyChildren = new cc.CallFunc(this.cannon.removeFromParent, this.cannon);
        var destroyChildren1 = new cc.CallFunc(this.cannon1.removeFromParent, this.cannon1);
        var seq = new cc.Sequence([tint, destroyChildren, destroyChildren1, destroy]);
        this.runAction(seq);
    },
    spawnBullet : function () {
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.cannon.getPosition()) <= cc.winSize.width * 4) {
            var bullet = new CannonBullet(res.cannonBall_png);
            bullet.setPosition(this.cannon.x, this.cannon.y);
            bullet.setRotation(this.cannon.getRotation() - 90);
            bullet.gameSceneLayer = this.gameSceneLayer;
            this.gameSceneLayer.addChild(bullet, 2);
        }
        if (cc.pDistance(this.gameSceneLayer.player.getPosition(), this.cannon1.getPosition()) <= cc.winSize.width * 4) {
            var bullet = new CannonBullet(res.cannonBall_png);
            bullet.setPosition(this.cannon1.x, this.cannon1.y);
            bullet.setRotation(this.cannon1.getRotation() - 90);
            bullet.gameSceneLayer = this.gameSceneLayer;
            this.gameSceneLayer.addChild(bullet, 2);
        }
    },
    update : function (dt) {
        this.setPosition(this.x + this.randomMove * dt, this.y);

        var vector = cc.pSub(this.cannon.getPosition(), this.gameSceneLayer.player.getPosition());
        var vn = cc.pNormalize(vector);

        var radian = cc.pToAngle(vn);
        var angle = radian * 180 / Math.PI;

        var vector1 = cc.pSub(this.cannon1.getPosition(), this.gameSceneLayer.player.getPosition());
        var vn1 = cc.pNormalize(vector1);

        var radian1 = cc.pToAngle(vn1);
        var angle1 = radian1 * 180 / Math.PI;

        this.cannon.setRotation(270 - angle);
        this.cannon.setPosition(this.x - 120, this.y - 30);

        this.cannon1.setRotation(270 - angle1);
        this.cannon1.setPosition(this.x + 120, this.y - 30);
    }
});
var Missile = cc.Sprite.extend({
    gameSceneLayer : null,
    countDown : 15,
    dead : false,
    onEnter : function () {
        this._super();
        this.scheduleUpdate();
    },
    update : function (dt) {
        this.countDown -= dt;

        if (this.countDown <= 0) {
            this.setOpacity(0);
            this.dead = true;
            var explosion = new cc.Sprite();
            explosion.setPosition(this.getPosition());

            var ani = new cc.Animation();
            for (var i = 1; i <= 9; i++){
                var fileName = "res/explosion" + i + ".png";
                ani.addSpriteFrameWithFile(fileName);
            }
            ani.setDelayPerUnit(0.02);
            ani.setLoops(1);

            var animate = new cc.Animate(ani);

            var destroy = new cc.CallFunc(this.removeFromParent, this);
            var destroySelf = new cc.CallFunc(explosion.removeFromParent, explosion);
            var seq = new cc.Sequence([animate, destroy, destroySelf]);
            explosion.runAction(seq);
            this.gameSceneLayer.addChild(explosion, 3);
        }

        var player = this.gameSceneLayer.player;
        var vector = cc.pSub(player.getPosition(), this.getPosition());
        var vn = cc.pNormalize(vector);

        var radian = cc.pToAngle(vn);
        var angle = radian * 180 / Math.PI;
        var realAngle = -angle - 90;

        var getR = this.getRotation();

        if (this.getRotation() > 360) {
            this.setRotation(this.getRotation() - 360);
        }
        if (this.getRotation() < 0) {
            this.setRotation(this.getRotation() + 360);
        }

        if (realAngle > 360) {
            realAngle = realAngle - 360;
        }
        if (realAngle < 0) {
            realAngle = realAngle + 360;
        }

        if (this.dead == false) {
            if ((getR > realAngle && getR < realAngle + 180) || getR < realAngle - 180) {
                this.setRotation(this.getRotation() + dt * 80);
            } else {
                this.setRotation(this.getRotation() - dt * 80);
            }
            this.setPosition(cc.pAdd(this.getPosition(), cc.pRotateByAngle(cc.p(460 * dt, 0), cc.p(0, 0), -((this.getRotation() - 90) / 360 * Math.PI * 2))));
            var coll = false;
            for (var i = 1; i <= 5; i++) {
                for (var j = 1; j <= 5; j++) {
                    if (cc.pDistance(cc.p(cc.pRotateByAngle(cc.p(player.getPosition().x + player.getContentSize().width / 2 - player.getContentSize().width + (player.getContentSize().width / 5 * i - player.getContentSize().width / 5 / 2), player.getPosition().y), cc.p(player.getPosition()), -(player.getRotation() / 360 * Math.PI * 2))), cc.p(cc.pRotateByAngle(cc.p(this.getPosition().x, this.getPosition().y + this.getContentSize().height / 2 - this.getContentSize().height + (this.getContentSize().height / 5 * j - this.getContentSize().height / 5 / 2)), cc.p(this.getPosition()), -(this.getRotation() / 360 * Math.PI * 2)))) <= 30) {
                        coll = true;
                        break;
                    }
                }
            }
            if (coll == true) {
                this.gameSceneLayer.player.hp -= 20;
                this.gameSceneLayer.backgroundLayer.updateHpBar();
                this.removeFromParent();
            }
        } else {
            this.setRotation(0);
        }
    }
});
var CannonBullet = cc.Sprite.extend({
    gameSceneLayer : null,
    countDown : 10,
    onEnter : function () {
        this._super();
        this.scheduleUpdate();
    },
    update : function (dt) {
        var player = this.gameSceneLayer.player;
        this.setPosition(cc.pAdd(this.getPosition(), cc.pRotateByAngle(cc.p(790 * dt, 0), cc.p(0, 0), -(this.getRotation() / 360 * Math.PI * 2))));
        var coll = false;
        for (var i = 1; i <= 5; i++) {
            if (cc.pDistance(cc.p(cc.pRotateByAngle(cc.p(player.getPosition().x + player.getContentSize().width / 2 - player.getContentSize().width + (player.getContentSize().width / 5 * i - player.getContentSize().width / 5 / 2), player.getPosition().y), cc.p(player.getPosition()), -(player.getRotation() / 360 * Math.PI * 2))), this.getPosition()) <= 30) {
                coll = true;
                break;
            }
        }
        if (coll == true) {
            this.gameSceneLayer.player.hp -= 2;
            this.gameSceneLayer.backgroundLayer.updateHpBar();
            this.removeFromParent();
        }
        this.countDown -= dt;
        if (this.countDown <= 0) {
            this.removeFromParent();
        }
    }
});
var PlayerBullet = cc.Sprite.extend({
    gameSceneLayer : null,
    countDown : 20,
    onEnter : function () {
        this._super();
        this.scheduleUpdate();
    },
    update : function (dt) {
        this.setPosition(cc.pAdd(this.getPosition(), cc.pRotateByAngle(cc.p(1280 * dt, 0), cc.p(0, 0), -(this.getRotation() / 360 * Math.PI * 2))));
        for (var i in this.gameSceneLayer.boatArray) {
            if (cc.rectIntersectsRect(cc.rect(this.x, this.y, this.getContentSize().width, this.getContentSize().height), cc.rect(this.gameSceneLayer.boatArray[i].x - this.gameSceneLayer.boatArray[i].getContentSize().width / 2, this.gameSceneLayer.boatArray[i].y - this.gameSceneLayer.boatArray[i].getContentSize().height / 2, this.gameSceneLayer.boatArray[i].getContentSize().width, this.gameSceneLayer.boatArray[i].getContentSize().height))) {
                this.gameSceneLayer.boatArray[i].loseHealth(1);
                this.removeFromParent();
            }
        }
        this.countDown -= dt;
        if (this.countDown <= 0) {
            this.removeFromParent();
        }
    }
});
var PlayerBomb = cc.Sprite.extend({
    gameSceneLayer : null,
    gravity : 0.15,
    maxGravity : 8,
    countDown : 40,
    downForce : 5,
    onEnter : function () {
        this._super();
        this.scheduleUpdate();
    },
    update : function (dt) {
        if (this.downForce < this.maxGravity) {
            this.downForce = this.downForce + this.gravity;
        }
        this.setPosition(this.x, this.y - this.downForce);
        for (var i in this.gameSceneLayer.boatArray) {
            if (cc.rectIntersectsRect(cc.rect(this.x, this.y, this.getContentSize().width, this.getContentSize().height), cc.rect(this.gameSceneLayer.boatArray[i].x - this.gameSceneLayer.boatArray[i].getContentSize().width / 2, this.gameSceneLayer.boatArray[i].y - this.gameSceneLayer.boatArray[i].getContentSize().height / 2, this.gameSceneLayer.boatArray[i].getContentSize().width, this.gameSceneLayer.boatArray[i].getContentSize().height))) {
                this.gameSceneLayer.boatArray[i].loseHealth(6);
                this.removeFromParent();
            }
        }
        this.countDown -= dt;
        if (this.countDown <= 0) {
            this.removeFromParent();
        }
    }
});