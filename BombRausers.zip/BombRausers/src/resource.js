var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    bomber_png : "res/Bomber.png",
    bomb_png : "res/Bomb.png",
    bullet_png : "res/Bullet.png",
    sailBoat_png : "res/SailBoat.png",
    background_png : "res/Background.png",
    water_png : "res/Water.png",
    boatCannon_png : "res/BoatCannon.png",
    cannonBall_png : "res/Cannonball.png",
    cloud_png : "res/Cloud.png",
    sand_png : "res/Border.png",
    cargoBoat_png : "res/Cargo.png",
    redHpBar_png : "res/RedBar.png",
    greenHpBar_png : "res/GreenBar.png",
    buttonUp_png : "res/ButtonUp.png",
    buttonDown_png : "res/ButtonDown.png",
    bombDisplay_png : "res/BombDisplay.png",
    bulletDisplay_png : "res/BulletDisplay.png",
    missile_png : "res/Missile.png",
    carrier_png : "res/Carrier.png",
    menuButton_png : "res/MenuButton.png",
    menuButtonPressed_png : "res/MenuButtonPressed.png",
    grayShade_png : "res/GrayShade.png",
    gameOverText_png : "res/GameOverText.png",
    bulletButton_png : "res/BulletButton.png",
    bombButton_png : "res/BombButton.png",
    leftButton_png : "res/LeftArrow.png",
    rightButton_png : "res/RightArrow.png",
    upButton_png : "res/UpArrow.png",
    settings_png : "res/Settings.png",
    pause_png : "res/Pause.png",
    resumeButton_png : "res/ResumeButton.png",
    resumeButtonPressed_png : "res/ResumeButtonPressed.png",
    startBackground_png : "res/StartBackground.png"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}